import { createRequire } from "module";
const require = createRequire(import.meta.url);
const AWS = require("aws-sdk");
import Stripe from "stripe";

const sm = new AWS.SecretsManager({ region: process.env.AWS_REGION || "us-east-1" });
const ddb = new AWS.DynamoDB.DocumentClient();
const ses = new AWS.SES({ region: process.env.AWS_REGION || "us-east-1" });

const ORDERS_TABLE = process.env.ORDERS_TABLE_NAME || "orders";
const ORDER_WEIGHT_OZ = Number(process.env.ORDER_WEIGHT_OZ || "15");
const SES_FROM_ADDRESS = process.env.SES_FROM_ADDRESS || "hello@shopallureher.com";

let stripeClient = null;
async function getStripe() {
  if (stripeClient) return stripeClient;

  let key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    const secretId =
      process.env.STRIPE_SECRET_ARN ||
      process.env.STRIPE_SECRET_ID ||
      "stripe/my-site/secret-key";

    const sv = await sm.getSecretValue({ SecretId: secretId }).promise();
    let raw =
      sv.SecretString ||
      (sv.SecretBinary ? Buffer.from(sv.SecretBinary, "base64").toString("utf8") : null);

    if (!raw) throw new Error("Stripe secret not found in Secrets Manager");

    try {
      const obj = JSON.parse(raw);
      key = obj["stripe-secret-key"] || obj["stripe_secret_key"] || obj["STRIPE_SECRET_KEY"];
      if (!key) {
        for (const v of Object.values(obj)) {
          if (typeof v === "string" && v.startsWith("sk_")) { key = v; break; }
        }
      }
    } catch {
      key = raw;
    }
  }

  if (!key || !/^sk_(live|test)_/.test(key)) {
    throw new Error("Stripe secret key not found or invalid format");
  }

  stripeClient = new Stripe(key);
  return stripeClient;
}

const allowedOrigins = new Set([
  "https://shopallureher.com",
  "https://www.shopallureher.com",
  "http://localhost:5173",
]);

function corsHeaders(event) {
  const origin = event?.headers?.origin || event?.headers?.Origin || "";
  const allowOrigin = allowedOrigins.has(origin) ? origin : "https://shopallureher.com";
  return {
    "Access-Control-Allow-Origin": allowOrigin,
    "Vary": "Origin",
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Headers": "content-type,authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
  };
}

function withSessionId(url) {
  if (!url) return url;
  if (url.includes("{CHECKOUT_SESSION_ID}")) return url;
  try {
    const parsed = new URL(url);
    if (!parsed.searchParams.has("session_id")) {
      parsed.searchParams.set("session_id", "{CHECKOUT_SESSION_ID}");
    }
    return parsed.toString();
  } catch {
    return url.includes("session_id=") ? url : `${url}?session_id={CHECKOUT_SESSION_ID}`;
  }
}

function formatCurrency(amountCents, currency) {
  if (typeof amountCents !== "number") return "";
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: (currency || "USD").toUpperCase(),
    }).format(amountCents / 100);
  } catch {
    return `${(amountCents / 100).toFixed(2)} ${currency || "USD"}`;
  }
}

async function sendConfirmationEmail(order) {
  if (!order?.email) return;

  const itemsHtml = (order.items || [])
    .map(
      (item) =>
        `<li>${item.quantity} x ${item.name} (${formatCurrency(
          Math.round((item.price || 0) * 100),
          order.currency
        )})</li>`
    )
    .join("");

  const address = order.shippingAddress || {};
  const addressLines = [
    address.line1,
    address.line2,
    [address.city, address.state, address.postal_code].filter(Boolean).join(", "),
    address.country || "US",
  ]
    .filter(Boolean)
    .join("\n");

  const subject = `Order confirmation ${order.orderId}`;
  const textBody = `Thank you for your order!\n\nOrder ID: ${order.orderId}\n\nItems:\n${(order.items || [])
    .map((item) => `- ${item.quantity} x ${item.name}`)
    .join("\n")}\n\nTotal: ${formatCurrency(
    Math.round((order.total || 0) * 100),
    order.currency
  )}\n\nShipping to:\n${addressLines}`;

  const htmlBody = `
    <div>
      <h2>Thank you for your order!</h2>
      <p><strong>Order ID:</strong> ${order.orderId}</p>
      <h3>Items</h3>
      <ul>${itemsHtml}</ul>
      <p><strong>Total:</strong> ${formatCurrency(
        Math.round((order.total || 0) * 100),
        order.currency
      )}</p>
      <h3>Shipping to</h3>
      <pre>${addressLines}</pre>
    </div>
  `;

  await ses
    .sendEmail({
      Source: SES_FROM_ADDRESS,
      Destination: { ToAddresses: [order.email] },
      Message: {
        Subject: { Data: subject },
        Body: {
          Text: { Data: textBody },
          Html: { Data: htmlBody },
        },
      },
    })
    .promise();
}

async function handleConfirm(body) {
  const sessionId = body?.sessionId;
  if (!sessionId) {
    return { statusCode: 400, body: { error: "sessionId required" } };
  }

  const stripe = await getStripe();
  const session = await stripe.checkout.sessions.retrieve(sessionId);

  if (!session || session.payment_status !== "paid") {
    return { statusCode: 409, body: { error: "payment_not_confirmed" } };
  }

  const lineItems = await stripe.checkout.sessions.listLineItems(sessionId, { limit: 100 });
  const items = (lineItems.data || []).map((item) => {
    const unitAmount = item.price?.unit_amount ?? (item.amount_total ? item.amount_total / item.quantity : 0);
    return {
      name: item.description || item.price?.product?.name || "Item",
      quantity: item.quantity || 1,
      price: (unitAmount || 0) / 100,
      weight: ORDER_WEIGHT_OZ,
    };
  });

  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalWeight = items.reduce((sum, item) => sum + (item.weight || 0) * item.quantity, 0);

  const shippingAddress = session.shipping_details?.address
    ? {
        name: session.shipping_details?.name,
        line1: session.shipping_details?.address?.line1,
        line2: session.shipping_details?.address?.line2,
        city: session.shipping_details?.address?.city,
        state: session.shipping_details?.address?.state,
        postal_code: session.shipping_details?.address?.postal_code,
        country: session.shipping_details?.address?.country,
      }
    : undefined;

  const order = {
    orderId: session.id,
    siteId: session.metadata?.siteId || body?.siteId || process.env.SITE_ID_DEFAULT || "my-site",
    customerName: session.customer_details?.name || session.shipping_details?.name || "Customer",
    email: session.customer_details?.email || session.customer_email || "",
    phone: session.customer_details?.phone,
    status: "NEW",
    total: typeof session.amount_total === "number" ? session.amount_total / 100 : 0,
    subtotal: typeof session.amount_subtotal === "number" ? session.amount_subtotal / 100 : undefined,
    shippingCost: typeof session.total_details?.amount_shipping === "number"
      ? session.total_details.amount_shipping / 100
      : undefined,
    taxAmount: typeof session.total_details?.amount_tax === "number"
      ? session.total_details.amount_tax / 100
      : undefined,
    currency: session.currency?.toUpperCase(),
    shippingMethod: "Standard",
    items,
    totalQuantity,
    totalWeight,
    shippingAddress,
    createdAt: session.created ? new Date(session.created * 1000).toISOString() : new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const existing = await ddb.get({ TableName: ORDERS_TABLE, Key: { orderId: order.orderId } }).promise();
  if (existing.Item?.confirmationSentAt) {
    return { statusCode: 200, body: { alreadyConfirmed: true, orderId: order.orderId } };
  }

  const merged = { ...(existing.Item || {}), ...order };
  await ddb.put({ TableName: ORDERS_TABLE, Item: merged }).promise();

  await sendConfirmationEmail(order);

  await ddb.update({
    TableName: ORDERS_TABLE,
    Key: { orderId: order.orderId },
    UpdateExpression: "SET confirmationSentAt = :ts, confirmationEmail = :em, updatedAt = :u",
    ExpressionAttributeValues: {
      ":ts": new Date().toISOString(),
      ":em": order.email,
      ":u": new Date().toISOString(),
    },
  }).promise();

  return { statusCode: 200, body: { confirmed: true, orderId: order.orderId } };
}

export const handler = async (event) => {
  const cors = corsHeaders(event);
  const method = (event?.requestContext?.http?.method || "").toUpperCase();

  const rawPath = event?.requestContext?.http?.path || event?.rawPath || "";
  let path = rawPath;
  const stage = event?.requestContext?.stage;
  if (stage && path.startsWith(`/${stage}`)) {
    path = path.slice(stage.length + 1);
  }

  if (method === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }

  const DEBUG = process.env.DEBUG === "true";

  try {
    const body =
      typeof event?.body === "string"
        ? JSON.parse(event.body || "{}")
        : (event?.body || {});

    if (method === "POST" && path === "/public/checkout/confirm") {
      const result = await handleConfirm(body);
      return {
        statusCode: result.statusCode,
        headers: { ...cors, "Content-Type": "application/json" },
        body: JSON.stringify(result.body),
      };
    }

    const siteId = body.siteId || process.env.SITE_ID_DEFAULT || "unknown-site";
    const uiMode = body.uiMode === "embedded" ? "embedded" : "hosted";
    const mode = body.mode || "payment";

    const line_items = Array.isArray(body.lineItems) ? body.lineItems : [];
    if (!line_items.length) {
      return {
        statusCode: 400,
        headers: { ...cors, "Content-Type": "application/json" },
        body: JSON.stringify({ error: "lineItems required" }),
      };
    }

    const shipping_address_collection =
      body.shipping_address_collection || { allowed_countries: ["US"] };

    const shippingCostCents = Number(body.shippingCostCents);
    const shipping_options =
      Number.isFinite(shippingCostCents) && shippingCostCents >= 0
        ? [
            {
              shipping_rate_data: {
                display_name: body.shippingQuote?.service || body.shippingQuote?.carrier || "Shipping",
                type: "fixed_amount",
                fixed_amount: { amount: Math.round(shippingCostCents), currency: "usd" },
              },
            },
          ]
        : body.shipping_options || [
            {
              shipping_rate_data: {
                display_name: "Standard",
                type: "fixed_amount",
                fixed_amount: { amount: 0, currency: "usd" },
                delivery_estimate: {
                  minimum: { unit: "business_day", value: 3 },
                  maximum: { unit: "business_day", value: 5 },
                },
              },
            },
            {
              shipping_rate_data: {
                display_name: "Express",
                type: "fixed_amount",
                fixed_amount: { amount: 1200, currency: "usd" },
                delivery_estimate: {
                  minimum: { unit: "business_day", value: 1 },
                  maximum: { unit: "business_day", value: 2 },
                },
              },
            },
          ];

    const origin =
      event?.headers?.origin || event?.headers?.Origin || "https://shopallureher.com";

    const success_url = withSessionId(
      body.successUrl || process.env.STRIPE_SUCCESS_URL || "https://example.com/success"
    );

    const cancel_url =
      body.cancelUrl || process.env.STRIPE_CANCEL_URL || "https://example.com/cancel";

    const return_url = withSessionId(
      body.returnUrl || process.env.STRIPE_RETURN_URL || (origin + "/checkout/return")
    );

    const stripeAccount =
      body.stripeAccount || process.env.STRIPE_CONNECT_ACCOUNT_ID || undefined;

    const stripe = await getStripe();

    const createArgs = {
      mode,
      line_items,
      customer_email: body.customer?.email || body.customer_email || undefined,
      billing_address_collection: body.billing_address_collection || "auto",
      shipping_address_collection,
      shipping_options,
      metadata: { siteId },
      ...(uiMode === "embedded"
        ? { ui_mode: "embedded", return_url }
        : { success_url, cancel_url }),
    };

    const session = await stripe.checkout.sessions.create(
      createArgs,
      stripeAccount ? { stripeAccount } : undefined
    );

    const payload =
      uiMode === "embedded"
        ? { id: session.id, clientSecret: session.client_secret }
        : { id: session.id, url: session.url };

    return {
      statusCode: 200,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    };
  } catch (err) {
    console.error("checkout_error", {
      message: err?.message,
      code: err?.code,
      type: err?.type,
      stack: err?.stack,
    });

    const out = DEBUG
      ? { error: "stripe_error", message: err?.message, code: err?.code, type: err?.type }
      : { error: "internal_error" };

    return {
      statusCode: 500,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify(out),
    };
  }
};
